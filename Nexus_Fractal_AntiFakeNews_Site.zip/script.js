function analisarTexto() {
  const texto = document.getElementById('textInput').value.toLowerCase();
  const resultado = document.getElementById('resultado');
  if (texto.includes('conspiração') || texto.includes('mentira') || texto.includes('teoria')) {
    resultado.innerHTML = '<strong>Resultado:</strong> Incompatível com padrões fractais (risco de desinformação detectado).';
    resultado.style.color = 'red';
  } else if (texto.length > 100 && texto.includes('.') && texto.includes(',')) {
    resultado.innerHTML = '<strong>Resultado:</strong> Alinhado com estrutura de verdade fractal.';
    resultado.style.color = 'lightgreen';
  } else {
    resultado.innerHTML = '<strong>Resultado:</strong> Estrutura ambígua – verificação adicional recomendada.';
    resultado.style.color = 'orange';
  }
}
